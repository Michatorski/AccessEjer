# Recuperación 1ª evaluación de Acceso a datos

## Configuración y entrega

### Configuración del entorno

Se deben crear tres proyectos INDEPENDIENTES en IntelliJ Idea, para ello se deben realizar los siguientes pasos:

1. Abrir la terminal
2. Descargar el repositorio del examen

```bash
git clone https://github.com/mikelsanvi/rec1accdatos.git
```
3. Arrancar el contendor Docker de Mysql
4. Cargar la base de datos ejecutando
```bash
docker exec -i instituto mysql -u root -pfederica < rec1accdatos/jdbc/src/main/resources/database.sql
```
5. Abrir IntelliJ Idea
6. File -> New -> Project from existing sources -> rec1accesodatos/serialization -> Import project from external model (maven) -> This Window
7. File -> New -> Project from existing sources -> rec1accesodatos/ficheros -> Import project from external model (maven) -> New Window
8. File -> New -> Project from existing sources -> rec1accesodatos/jdbc -> Import project from external model (maven) -> New Window

### Entregar el examen

Desde el directorio de usuario ejecutar

```bash
tar cvfz rec1accdatos.tar.gz rec1accdatos
```

Subir a la tarea el fichero rec1accdatos.tar.gz

## Enunciado

### Serialization (3 puntos) 

Implementa un programa que realice lo siguiente:
- Lee el fichero highschool.json del classpath
- Convierta el JSON que contiene en un objeto de tipo Highschool
- Muestra toda la información del instituto. Para esto recorre la estructura de clases haciendo log.info de todos los campos


### Ficheros (3 puntos) 

Proyecto ficheros. Implementa un programa que realice lo siguiente:
- Lee el fichero que hay en el classpath llamado `users.txt` (contiene nombres de usuario) y devuelve una `List<String>` con todas las líneas
- A partir de la lista de usuario (lo que devuelve el punto anterior), crea un fichero por cada usuario en `/tmp/<username>.txt`
- Escribe dentro de cada fichero el texto "Creado"


### JDBC (4 puntos) 

Implementa los métodos definidos en FlightDAO y PassengerDAO. Para comprobar que los métodos son correctos puedes implementar test unitarios que realicen las operaciones que has implementado.