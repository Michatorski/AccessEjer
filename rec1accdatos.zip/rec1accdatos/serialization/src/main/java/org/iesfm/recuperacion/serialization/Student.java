package org.iesfm.recuperacion.serialization;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;

import java.util.Objects;

public class Student {
    private static final Logger log = LoggerFactory.getLogger(Title.class);

    private String name;
    private String surname;
    @JsonFormat(pattern = "dd/MM/yyyy")
    private Date birthDate;

    public Student(
            @JsonProperty("name") String name,
            @JsonProperty("surname") String surname,
            @JsonProperty("birthDate") Date birthDate) {
        this.name = name;
        this.surname = surname;
        this.birthDate = birthDate;
    }

    public void showInfo() {
        log.info("Nombre: " + name);
        log.info("Apellido: " + surname);
        log.info("Fecha de nacimiento: " + birthDate);

    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Student student = (Student) o;
        return Objects.equals(name, student.name) && Objects.equals(surname, student.surname) && Objects.equals(birthDate, student.birthDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, surname, birthDate);
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", surname='" + surname + '\'' +
                ", birthdate=" + birthDate +
                '}';
    }
}
