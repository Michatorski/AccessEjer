package org.iesfm.recuperacion.serialization;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.util.List;
import java.util.Objects;

public class Title {
    private static final Logger log = LoggerFactory.getLogger(Title.class);

    private String name;
    @JsonProperty("class")
    private String type;
    private String level;
    private int lines;
    private List<String> tags;

    public Title(
            @JsonProperty("name") String name,
            @JsonProperty("class") String type,
            @JsonProperty("level") String level,
            @JsonProperty("lines") int lines,
            @JsonProperty("tags") List<String> tags) {
        this.name = name;
        this.type = type;
        this.level = level;
        this.lines = lines;
        this.tags = tags;
    }

    public void showInfo() {
        log.info("Nombre: " + name);
        log.info("Clase: " + type);
        log.info("Nivel: " + level);
        log.info("Lineas: " + lines);
        log.info("Etiquetas: ");
        for (String tag : tags) {
            log.info(tag);
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public int getLines() {
        return lines;
    }

    public void setLines(int lines) {
        this.lines = lines;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Title title = (Title) o;
        return lines == title.lines && Objects.equals(name, title.name) && Objects.equals(type, title.type) && Objects.equals(level, title.level) && Objects.equals(tags, title.tags);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, type, level, lines, tags);
    }

    @Override
    public String toString() {
        return "Title{" +
                "name='" + name + '\'' +
                ", type='" + type + '\'' +
                ", level='" + level + '\'' +
                ", lines=" + lines +
                ", tags=" + tags +
                '}';
    }
}
