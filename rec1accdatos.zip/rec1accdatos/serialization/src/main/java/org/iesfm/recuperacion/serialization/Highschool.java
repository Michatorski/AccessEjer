package org.iesfm.recuperacion.serialization;


import com.fasterxml.jackson.annotation.JsonProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.util.List;
import java.util.Objects;

public class Highschool {
    private static final Logger log = LoggerFactory.getLogger(Title.class);

    private String name;
    private String address;
    private String city;
    private List<Student> students;
    private List<Title> titles;

    public Highschool(
            @JsonProperty("name") String name,
            @JsonProperty("address") String address,
            @JsonProperty("city") String city,
            @JsonProperty("students") List<Student> students,
            @JsonProperty("titles") List<Title> titles) {
        this.name = name;
        this.address = address;
        this.city = city;
        this.students = students;
        this.titles = titles;
    }

    public void showInfo() {
        log.info("Nombre: " + name);
        log.info("Direccion: " + address);
        log.info("Ciudad: " + city);
        log.info("Estudiantes: ");
        for (Student student: students){
            student.showInfo();
        }
        log.info("Titulos: ");
        for (Title title: titles){
            title.showInfo();
        }

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }

    public List<Title> getTitles() {
        return titles;
    }

    public void setTitles(List<Title> titles) {
        this.titles = titles;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Highschool that = (Highschool) o;
        return Objects.equals(name, that.name) && Objects.equals(address, that.address) && Objects.equals(city, that.city) && Objects.equals(students, that.students) && Objects.equals(titles, that.titles);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, address, city, students, titles);
    }

    @Override
    public String toString() {
        return "Highschool{" +
                "name='" + name + '\'' +
                ", address='" + address + '\'' +
                ", city='" + city + '\'' +
                ", students=" + students +
                ", titles=" + titles +
                '}';
    }
}
