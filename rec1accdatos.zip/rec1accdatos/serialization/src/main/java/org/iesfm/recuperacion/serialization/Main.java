package org.iesfm.recuperacion.serialization;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;

public class Main {
    public static void main(String[] args) throws URISyntaxException, IOException {
        ObjectMapper om = new ObjectMapper();
        Highschool highschool = om.readValue(new File(Main.class.getResource("/highschool.json").toURI()), Highschool.class);

        highschool.showInfo();
    }
}
