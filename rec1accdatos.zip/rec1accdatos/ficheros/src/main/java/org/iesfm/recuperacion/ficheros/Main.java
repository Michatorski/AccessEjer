package org.iesfm.recuperacion.ficheros;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.URISyntaxException;

public class Main {
    public static void main(String[] args) throws FileNotFoundException, URISyntaxException {
        ReadUtils readUtils = new ReadUtils(new File(Main.class.getResource("/users.txt").toURI()));
        WriteUtils writeUtils = new WriteUtils();
        writeUtils.makeFiles(readUtils.readFile());
    }

}
