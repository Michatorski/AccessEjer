package org.iesfm.recuperacion.ficheros;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ReadUtils {
    private File file;

    public ReadUtils(File file) {
        this.file = file;
    }

    public List<String> readFile() throws FileNotFoundException {

        try(BufferedReader reader = new BufferedReader(new FileReader(file))){
            List<String> list = new ArrayList<>();
            String line = null;

            while ((line = reader.readLine()) != null){
                list.add(line);
            }
            return list;

        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}

