package org.iesfm.recuperacion.ficheros;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class WriteUtils {

    public void makeFiles(List<String> userList) {
        for (String user : userList) {
            try (FileWriter writer = new FileWriter(new File("/tmp/" + user + ".txt"))) {
                writer.write("Creado");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
