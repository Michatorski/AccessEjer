DROP DATABASE IF EXISTS airline;

CREATE DATABASE IF NOT EXISTS airline;

USE airline;

CREATE TABLE IF NOT EXISTS flight (
    flight_number VARCHAR(20) PRIMARY KEY,
	origin VARCHAR(20) NOT NULL,
	destination VARCHAR (20) NOT NULL
);

CREATE TABLE IF NOT EXISTS passenger (
	nif VARCHAR (10) NOT NULL,
	flight_number VARCHAR(20) NOT NULl,
	name VARCHAR(20) not null,
	surname VARCHAR(20) not null,
	seat INT NOT NULL,
	PRIMARY KEY(nif, flight_number),
	CONSTRAINT FK_FLIGHT_PASSENGER
	FOREIGN KEY (flight_number)
	REFERENCES flight (flight_number)
	ON UPDATE CASCADE
    ON DELETE RESTRICT
);

INSERT INTO flight(flight_number, origin, destination) VALUES ('MAD001112', 'Madrid', 'Londres');
INSERT INTO flight(flight_number, origin, destination) VALUES ('MAD001113', 'Londres', 'Madrid');

INSERT INTO passenger(nif, flight_number, name, surname, seat) VALUES('0000000X', 'MAD001112', 'Peppa', 'Pig', 1);
INSERT INTO passenger(nif, flight_number, name, surname, seat) VALUES('0000001X', 'MAD001112', 'Bob', 'Esponja', 1);

