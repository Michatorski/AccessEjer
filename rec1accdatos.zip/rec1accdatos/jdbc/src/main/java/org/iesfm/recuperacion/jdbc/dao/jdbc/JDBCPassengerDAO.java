package org.iesfm.recuperacion.jdbc.dao.jdbc;

import org.iesfm.recuperacion.jdbc.Passenger;
import org.iesfm.recuperacion.jdbc.dao.PassengerDAO;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JDBCPassengerDAO implements PassengerDAO {


    private static final String SELECT_PASSENGER_BY_ORIGIN = "SELECT p.* FROM passenger p INNER JOIN flight f ON p.flight_number=f.flight_number WHERE origin = :origin";

    public NamedParameterJdbcTemplate jdbc;

    public JDBCPassengerDAO(NamedParameterJdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    public List<Passenger> getPassengersFromOrigin(String origin) {

        Map<String, Object> params = new HashMap<>();
        params.put("origin", origin);

        return jdbc.query(SELECT_PASSENGER_BY_ORIGIN, params, (rs, rowNum) -> new Passenger(
                rs.getString("nif"),
                rs.getString("flight_number"),
                rs.getString("name"),
                rs.getString("surname"),
                rs.getInt("seat")
        ));
    }
}
