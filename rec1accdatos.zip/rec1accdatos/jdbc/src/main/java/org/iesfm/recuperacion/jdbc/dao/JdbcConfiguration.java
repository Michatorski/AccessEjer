package org.iesfm.recuperacion.jdbc.dao;

import org.iesfm.recuperacion.jdbc.Flight;
import org.iesfm.recuperacion.jdbc.dao.jdbc.JDBCFlightDAO;
import org.iesfm.recuperacion.jdbc.dao.jdbc.JDBCPassengerDAO;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;

@Configuration
@PropertySource("application.properties")
public class JdbcConfiguration {

    @Bean
    public NamedParameterJdbcTemplate jdbc(DataSource source) {
        return new NamedParameterJdbcTemplate(source);
    }

    @Bean
    public PassengerDAO passengerDAO(NamedParameterJdbcTemplate jdbc) {
        return new JDBCPassengerDAO(jdbc);
    }

    @Bean
    public FlightDAO flightDAO(NamedParameterJdbcTemplate jdbc){
        return new JDBCFlightDAO(jdbc);
    }

    @Bean
    public DataSource mysqlDataSource(
            @Value("${database.url}") String url,
            @Value("${database.user}") String user,
            @Value("${database.password}") String passwd,
            @Value("${database.driver}") String driver
    ) {
        DriverManagerDataSource driverManager = new DriverManagerDataSource();
        driverManager.setUrl(url);
        driverManager.setUsername(user);
        driverManager.setPassword(passwd);
        driverManager.setDriverClassName(driver);
        return driverManager;
    }

}
