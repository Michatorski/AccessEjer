package org.iesfm.recuperacion.jdbc.dao;


import org.iesfm.recuperacion.jdbc.Flight;

public interface FlightDAO {


    /**
     * Devuelve el vuelo con el número de vuelo proporciondo
     * @param flightNumber
     * @return Si no se encuentra el vuelo devuelve null
     */
    Flight getFlight(String flightNumber);

    /**
     * Añade un vuelo, si no existía otro vuelo con el mismo flightNumber
     *
     * @param flight El vuelo que se va a añadir
     * @return Si ya había un vuelo con el mismo fligthNumber devuelve false y no se inserta
     */
    boolean saveFlight(Flight flight);

    /**
     * Elimina el vuelo con el flightNumber
     * @param flightNumber El flightNumber a eliminar
     * @return Devuelve false si no existía el vuelo
     */
    boolean deleteFlight(String flightNumber);

    /**
     * Actualiza el vuelo
     * @param flight El vuelo a actualizar
     * @return Si no había un vuelo con el mismo fligthNumber devuelve false
     */
    boolean updateFlight(Flight flight);
}
