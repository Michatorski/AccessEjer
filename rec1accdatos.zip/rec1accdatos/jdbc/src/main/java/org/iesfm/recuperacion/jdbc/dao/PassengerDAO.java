package org.iesfm.recuperacion.jdbc.dao;

import org.iesfm.recuperacion.jdbc.Passenger;

import java.util.List;

public interface PassengerDAO {

    /**
     * Devuelve todos los pasajeros cuyo vuelo tiene un origen dado
     * @param origin El origen del vuelo
     * @return
     */
    List<Passenger> getPassengersFromOrigin(String origin);


}
