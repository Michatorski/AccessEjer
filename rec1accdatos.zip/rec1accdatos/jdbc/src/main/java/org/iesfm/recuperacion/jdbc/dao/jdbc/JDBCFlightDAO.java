package org.iesfm.recuperacion.jdbc.dao.jdbc;

import org.iesfm.recuperacion.jdbc.Flight;
import org.iesfm.recuperacion.jdbc.dao.FlightDAO;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.util.HashMap;
import java.util.Map;

public class JDBCFlightDAO implements FlightDAO {


    private static final String SELECT_FLIGHT = "SELECT * FROM flight WHERE flight_number =:flight_number";
    private static final String INSERT_FLIGHT = "INSERT INTO flight (flight_number, origin, destination)" +
            " VALUES (:flight_number, :origin, :destination)";
    private static final String DELETE_FLIGHT = "DELETE FROM flight WHERE flight_number =:flight_number";
    private static final String UPDATE_FLIGHT = " UPDATE flight SET  origin =:origin, destination =:destination  WHERE flight_number =:flight_number";

    public NamedParameterJdbcTemplate jdbc;

    public JDBCFlightDAO(NamedParameterJdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    public Flight getFlight(String flightNumber) {
        try {
            Map<String , Object> params = new HashMap<>();
            params.put("flight_number",flightNumber);
            return jdbc.queryForObject(SELECT_FLIGHT, params, (rs, rowNum) -> new Flight(
                    rs.getString("flight_number"),
                    rs.getString("origin"),
                    rs.getString("destination")
            ));
        }catch (EmptyResultDataAccessException e){
            return null;
        }

    }

    @Override
    public boolean saveFlight(Flight flight) {
        try {
            Map<String , Object> params = new HashMap<>();
            params.put("flight_number", flight.getFlightNumber());
            params.put("origin", flight.getOrigin());
            params.put("destination", flight.getDestination());

            return jdbc.update(INSERT_FLIGHT, params) ==1;
        } catch (DuplicateKeyException e){
            return false;
        }
    }

    @Override
    public boolean deleteFlight(String flightNumber) {
        try {
            Map<String , Object> params = new HashMap<>();
            params.put("flight_number", flightNumber);

            return jdbc.update(DELETE_FLIGHT, params) ==1;
        } catch (DataIntegrityViolationException e){
            return false;
        }
    }

    @Override
    public boolean updateFlight(Flight flight) {
        try {
            Map<String , Object> params = new HashMap<>();
            params.put("flight_number", flight.getFlightNumber());
            params.put("origin", flight.getOrigin());
            params.put("destination", flight.getDestination());

            return jdbc.update(UPDATE_FLIGHT, params) ==1;
        } catch (DataIntegrityViolationException e){
            return false;
        }
    }
}
