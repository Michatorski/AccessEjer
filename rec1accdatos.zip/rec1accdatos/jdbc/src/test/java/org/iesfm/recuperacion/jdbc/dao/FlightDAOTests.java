package org.iesfm.recuperacion.jdbc.dao;


import org.iesfm.recuperacion.jdbc.Flight;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {JdbcConfiguration.class})
public class FlightDAOTests {
    @Autowired
    private FlightDAO flightDAO;

    @Test
    public void getFlightTest(){
        Flight flight = flightDAO.getFlight("MAD001113");
        System.out.println(flight.toString());
    }

    @Test
    public void saveFlightTest(){
        boolean instertData = flightDAO.saveFlight(new Flight("XXXOOOMMM", "Madrid", "Lublin"));
    }

    @Test
    public void deleteFlightTest(){
        boolean deleteData = flightDAO.deleteFlight("XXXOOOMMM");
    }

    @Test
    public void updateFlightTest(){
        boolean updateData = flightDAO.updateFlight(new Flight("XXXOOOMMM", "Lublin", "Tokio"));
    }
}
