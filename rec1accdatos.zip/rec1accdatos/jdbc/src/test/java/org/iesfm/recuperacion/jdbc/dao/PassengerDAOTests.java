package org.iesfm.recuperacion.jdbc.dao;

import org.iesfm.recuperacion.jdbc.Passenger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {JdbcConfiguration.class})
public class PassengerDAOTests {

    @Autowired
    private PassengerDAO passengerDAO;

    @Test
    public void listTest() {
        List<Passenger> passengers = passengerDAO.getPassengersFromOrigin("Madrid");
        for (Passenger passenger: passengers){
            System.out.println(passenger.toString());
        }
    }
}
